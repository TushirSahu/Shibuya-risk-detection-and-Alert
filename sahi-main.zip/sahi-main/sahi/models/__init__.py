from . import base, detectron2, huggingface, mmdet, torchvision, yolonas, yolov5, yolov8onnx
