_base_ = ["cascade_mask_rcnn_r50_fpn_v280.py", "coco_instance.py", "schedule_1x.py", "default_runtime.py"]
